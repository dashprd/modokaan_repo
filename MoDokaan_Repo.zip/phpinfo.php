phpinfo.php
<?php
phpinfo();
?>